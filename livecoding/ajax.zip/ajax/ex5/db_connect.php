<?php

$hostname = "127.0.0.1";
$username = "root";
$password = "";
$dbname = "ajax-users";

$conn = new mysqli($hostname, $username, $password, $dbname);
